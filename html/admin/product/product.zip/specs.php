<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

include('../../../newconnect.php');
include('header.php');
?>
<div class="content mt-3">
<h1>sites/specs.php</h1>
coming soon
</div>
<?php
include '../footer.php';
?>