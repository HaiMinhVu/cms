<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

include('../../../newconnect.php');
include('header.php');
include('product_function.php');

$temp = $_GET['id'];
if(!preg_match('#[^0-9]#',$temp)){
    $productid = $temp;
}
else{
    //$productid = "";
    header('location:product.php');
}
?>

<!----------- WYSIWYG --------->
<script src="https://cdn.ckeditor.com/4.8.0/full-all/ckeditor.js"></script>



<div class="content mt-3"> <!-- begining of display content -->
<?php

$productinfo = product_info_by_id($cms_connect, $productid);
$product_manufacture = $productinfo['manufacture'];
$product_category = $productinfo['product_category_id'];

$productList = product_list_by_brand($cms_connect, $product_manufacture);

// feature product
$feature = '';
$featureArr = product_feature_by_id($cms_connect, $productid);
foreach($featureArr as $item){
	$feature .= $item.',';	
}
$feature = rtrim($feature,',');

// included product
$included = "";
$includedArr = product_included_by_id($cms_connect, $productid);
foreach($includedArr as $item){
	$included .= $item.',';	
}
$included = rtrim($included,',');

// related product
$related = '';
$relatedArr = product_related_by_id($cms_connect, $productid);
foreach($relatedArr as $item){
	$related .= $item.',';	
}
$related = rtrim($related,',');


$category_tree = json_encode(treeview_category_array($cms_connect, $productid));


?>
<span id="alert_action"></span>
    <div class="row">
        <div class="col-lg-12">
            <div class="card">
                <div class="card-header">
                    <div class="col-lg-6 col-md-6 col-sm-6 col-xs-6">
                        <strong class="card-title">View & Update Product: <?php echo $productinfo['sku']?></strong>
                    </div>
                    <div class="col-lg-6 col-md-6 col-sm-6 col-xs-6" align="right">
                        <button type="button" class="btn btn-outline-info btn-sm" title="Go Back" onclick="window.location.href='product.php'"><i class="fa fa-arrow-left"></i>&nbsp; Back</button>
                    </div>
                </div>
                <div class="card-body">
                	<ul class="nav nav-pills mb-3 justify-content-center" id="pills-tab" role="producttab">
	                    <li class="nav-item">
	                        <a class="nav-link active" id="pills-general-tab" data-toggle="pill" href="#pills-general" role="tab" aria-controls="pills-general" aria-selected="true">General</a>
	                    </li>
	                    <li class="nav-item">
	                        <a class="nav-link" id="pills-extra-tab" data-toggle="pill" href="#pills-extra" role="tab" aria-controls="pills-extra" aria-selected="false">Extra</a>
	                    </li>
	                    <li class="nav-item">
	                        <a class="nav-link" id="pills-category-tab" data-toggle="pill" href="#pills-category" role="tab" aria-controls="pills-category" aria-selected="false">Category</a>
	                    </li>
	                    <li class="nav-item">
	                        <a class="nav-link" id="pills-image-tab" data-toggle="pill" href="#pills-image" role="tab" aria-controls="pills-image" aria-selected="false">Image</a>
	                    </li>
	                </ul>
	               	
	                <div class="tab-content">
	                	<!-- start general tab -->
	                	<div class="tab-pane active" id="pills-general"> 
	                		<form method="POST" id="product_update_form" enctype="multipart/form-data">
			                	<div class="row form-group">
			                		<div class="col-md-3" align="right">Product Name <span style="color:red">*</span></div>
			                		<div class="col-md-6"><input type="text" name="product_name" value="<?php echo $productinfo['Name'];?>" class="form-control" required></div>
			                	</div>
			                	<div class="row form-group">
			                		<div class="col-md-3" align="right">SKU <span style="color:red">*</span></div>
			                		<div class="col-md-6"><input type="text" name="product_sku" value="<?php echo $productinfo['sku'];?>" class="form-control" required></div>
			                		<label  style="font-size:11px;opacity:0.6;float:right;">NS-SKU: <a href="https://system.na1.netsuite.com/app/common/item/item.nl?id=<?php echo $productinfo['sku'];?>" target="_blank"><?php echo $productinfo['sku'];?></a></label> 
			                	</div>
			                	<div class="row form-group">
			                		<div class="col-md-3" align="right">NSID&nbsp;&nbsp;&nbsp;</div>
			                		<div class="col-md-6"><input type="number" name="product_nsid" value="<?php echo $productinfo['nsid'];?>"min="0" step="1" class="form-control"></div>
			                		<label  style="font-size:11px;opacity:0.6;float:right;">NS-NSID: <a href="https://system.na1.netsuite.com/app/common/item/item.nl?id=<?php echo $productinfo['nsid'];?>" target="_blank"><?php echo $productinfo['nsid'];?></a></label> 
			                	</div>
			                	<div class="row form-group">
			                		<div class="col-md-3" align="right">UPC&nbsp;&nbsp;&nbsp;</div>
			                		<div class="col-md-6"><input type="text" name="product_upc" value="<?php echo $productinfo['UPC'];?>" class="form-control"></div>
			                	</div>
			                	<div class="row form-group">
			                		<div class="col-md-3" align="right">Manufacture <span style="color:red">*</span></div>
			                		<div class="col-md-6">
			                			<select name="product_manufacture" id="product_manufacture" class="form-control" required>
		                            		<option value="">--- Select One ---</option>
		                            		<?php echo manufacture_list($cms_connect);?>
		                        		</select>
		                    		</div>
			                	</div>
			                	<div class="row form-group">
			                		<div class="col-md-3" align="right">Product Sales Description&nbsp;&nbsp;&nbsp;</div>
			                		<div class="col-md-6"><input type="text" name="product_feature_name" value="<?php echo $productinfo['feature_name'];?>" class="form-control"></div>
			                	</div>
			                	<div class="row form-group">
			                		<div class="col-md-3" align="right">NSN&nbsp;&nbsp;&nbsp;</div>
			                		<div class="col-md-6"><input type="text" name="product_nsn" value="<?php echo $productinfo['nsn'];?>" class="form-control" ></div>
			                	</div>
			                	<div class="row form-group">
			                		<div class="col-md-3" align="right">Short Description&nbsp;&nbsp;&nbsp;</div>
			                		<div class="col-md-6"><textarea rows="5" name="store_description" id="product_store_description"><?php echo $productinfo['store_desc']?></textarea></div>
			                	</div>
			                	<div class="row form-group">
			                		<div class="col-md-3" align="right">Long Description&nbsp;&nbsp;&nbsp;</div>
			                		<div class="col-md-6"><textarea rows="10" name="feature_description" id="product_feature_description"><?php echo $productinfo['feature_desc']?></textarea></div>
			                	</div>
			                	<div class="row form-group">
			                		<div class="col-md-3" align="right">Netsuit Product Category <span style="color:red">*</span></div>
			                		<div class="col-md-6">
			                			<select name="product_category" id="product_category" class="form-control" required>
		                            		<option value="">--- Select One ---</option>
		                            		<?php echo category_list($cms_connect);?>
		                        		</select>
		                    		</div>
			                	</div>
			                	<div class="row form-group">
			                		<div class="col-md-3" align="right">Keywords&nbsp;&nbsp;&nbsp;</div>
			                		<div class="col-md-6"><input type="text" name="product_keywords" id="product_keywords" value="<?php echo $productinfo['keywords'];?>" /></div>

			                	</div>
			                	<div class="row form-group">
			                		<div class="col-md-3" align="right">Realease Date&nbsp;&nbsp;&nbsp;</div>
			                		<div class="col-md-6"><input type="date" name="product_start_date" class="form-control" value="<?php echo ($productinfo['start_date'] != '1969-12-31') ? $productinfo['start_date'] : "" ; ?>" /></div>

			                	</div>
		                	</form>
		                	<div style="text-align:center"> <!-- button submit form -->
						    	<button type="submit" class="btn btn-outline-info" title="Save" form="product_update_form"><i class="fa fa-floppy-o"></i>&nbsp; Save</button>
						    	<button type="button" class="btn btn-outline-warning" title="Reset" onClick="window.location.reload()"><i class="fa fa-refresh"></i>&nbsp; Reset</button>
						    </div>
	                	</div> 
	                	<!-- end general tab -->

	                	<!-- start extra tab -->
	                	<div class="tab-pane" id="pills-extra"> 
	                		<form method="POST" id="product_extra_form" enctype="multipart/form-data">
			                	<div class="row form-group">
			                		<div class="col-md-3" align="right">Product Feature</div>
			                		<div class="col-md-6"><input type="text" name="product_feature" id="product_feature" value="<?php echo $feature;?>"></div>
			                	</div>
			                	<div class="row form-group">
			                		<div class="col-md-3" align="right">Product Included</div>
			                		<div class="col-md-6"><input type="text" name="product_included" id="product_included" value="<?php echo $included;?>" ></div>
			                	</div>
			                	<div class="row form-group">
			                		<div class="col-md-3" align="right">Product Battery</div>
			                		<div class="col-md-6">

			                			<table class="table" id="battery_table">
						                    <thead><tr>
						                            <th width=40%>Battery Type</th>
						                            <th width=20%>Takes Battery</th>
						                            <th width=20%>Qty Included</th>
						                            <th width=20%>List Order</th>
						                            <th width=5%><button type="button" id="add_battery" class="btn btn-outline-info btn-sm" title="Add Battery"><i class="fa fa-plus"></i></button></th>
						                    </tr></thead>
						                    <tbody>
						                    <?php
					                        $batterysql = "SELECT * FROM product_battery WHERE product_id = $productid";
					                        $batterystmt = $cms_connect->query($batterysql);
					                        while ($brow = $batterystmt->fetch_assoc()) {
					                        	$tmp_battery_id = $brow['battery_id'];
						                    ?>
						                        <tr>
						                            <td><select name="battery_id[]" class="form-control" required>
						                            	<option value="">--- Select One ---</option>
						                                <?php echo battery_id_selected($cms_connect, $tmp_battery_id);?>
						                                </select></td>
						                            <td><input type="number" name="take_battery[]" value="<?php echo $brow['battery_qty'];?>" class="form-control" /></td>
						                            <td><input type="number" name="qty_included[]" value="<?php echo $brow['included'];?>" class="form-control" /></td>
						                            <td><input type="number" name="list_order[]" value="<?php echo $brow['battery_order'];?>" class="form-control" /></td>
						                            <td><button type="button" id="remove_battery" class="btn btn-outline-danger btn-sm delete" title="Remove Battery"><i class="fa fa-minus"></i></button></td>
						                        </tr>
						                    <?php
						                    }
						                    ?>
						                    </tbody>
						                </table>

			                		</div>
			                	</div>
			                	<div class="row form-group">
			                		<div class="col-md-3" align="right">Product Related</div>
			                		<div class="col-md-6">
			                			<select name="product_related[]" id="product_related" style="width: 100%" class="form-control" multiple="multiple">
		                            		<option value="">--- Select One ---</option>
		                            		<?php echo product_list_by_brand($cms_connect, $product_manufacture);?>
		                        		</select>
			                		</div>
			                	</div>
		                	</form>

		                	<div style="text-align:center"> <!-- button submit form -->
						    	<button type="submit" class="btn btn-outline-info" title="Save" form="product_extra_form"><i class="fa fa-floppy-o"></i>&nbsp; Save</button>
						    	<button type="button" class="btn btn-outline-warning" title="Reset" onClick="window.location.reload()"><i class="fa fa-refresh"></i>&nbsp; Reset</button>
						    </div>
	                	</div> 
	                	<!-- end extra tab -->

	                	<!-- start category tab -->
	                	<div class="tab-pane" id="pills-category"> 
	                		<form method="POST" id="product_category_form" enctype="multipart/form-data">
	                			<div class="row form-group">
			                		<div class="offset-md-2 col-md-8">
			                			<input type="text" class="form-control" placeholder="Search in tree" id="search" />
			                		</div>
		                		</div>
			                	<div class="row form-group">
			                		<div class="offset-md-2 col-md-8">
			                			<div id="cat_tree"></div>
			                		</div>
		                		</div>
		                		<input type="hidden" name="associatedCatID" id="associatedCatID">
		                	</form>
		                	<div style="text-align:center"> <!-- button submit form -->
						    	<button type="submit" class="btn btn-outline-info" title="Save" form="product_category_form"><i class="fa fa-floppy-o"></i>&nbsp; Save</button>
						    	<button type="button" class="btn btn-outline-warning" title="Reset" onClick="window.location.reload()"><i class="fa fa-refresh"></i>&nbsp; Reset</button>
						    </div>
	                	</div> 
	                	<!-- end category tab -->

	                	<!-- start image tab -->
	                	<div class="tab-pane" id="pills-image"> 
	                		<form method="POST" id="product_image_form" enctype="multipart/form-data">
	                			<div class="row form-group">
		                			<div class="col-md-3" align="right">Associated Images</div>
			                		<div class="col-md-6">
			                			<table class="table" id="image_table">
						                    <thead><tr>
						                            <th width=20%>Image</th>
						                            <th width=20%>Name</th>
						                            <th width=20%>Description</th>
						                            <th width=20%>Primary</th>
						                            <th width=20%>Disassociate</th>
						                    </tr></thead>
						                    <tbody id="image_table_body"></tbody>
						                </table>
			                		</div>
			                	</div>
			                	<div class="row form-group">
			                		<div class="col-md-3" align="right">Image List</div>
			                		<div class="col-md-6">
				                		<select id="imageids" class="selectpicker form-control show-tick" data-live-search="true" multiple data-style="btn-primary" data-actions-box="true" data-selected-text-format="count">
									        <?php echo all_image_select_option($cms_connect, $productinfo['manufacture'])?>
									    </select>
									</div>
		                		</div>
		                	</form>
		                	<div style="text-align:center"> <!-- button submit form -->
						    	<button type="submit" class="btn btn-outline-info" title="Save" form="product_image_form"><i class="fa fa-floppy-o"></i>&nbsp; Save</button>
						    	<button type="button" class="btn btn-outline-warning" title="Reset" onClick="window.location.reload()"><i class="fa fa-refresh"></i>&nbsp; Reset</button>
						    </div>
	                	</div> 
	                	<!-- end image tab -->


	                </div> <!-- end tab content-->
                </div>
            </div>
        </div>
    </div>
        
    

       

</div> <!-- end of display content -->


<script type="text/javascript">

$(document).ready(function(){
	
	$(window).on("load", function(){
		// display result after updating
		if(localStorage.getItem('update_general_result') != null){
            $('#alert_action').fadeIn().html('<div class="alert alert-info">'+localStorage.getItem('update_general_result')+'</div>');
            localStorage.removeItem('update_general_result');
        }
        if(localStorage.getItem('update_extra_result') != null){
            $('#alert_action').fadeIn().html('<div class="alert alert-info">'+localStorage.getItem('update_extra_result')+'</div>');
            localStorage.removeItem('update_extra_result');
        }
        if(localStorage.getItem('add_product_result') != null){
            $('#alert_action').fadeIn().html('<div class="alert alert-info">'+localStorage.getItem('add_product_result')+'</div>');
            localStorage.removeItem('add_product_result');
        }
        if(localStorage.getItem('update_category_result') != null){
            $('#alert_action').fadeIn().html('<div class="alert alert-info">'+localStorage.getItem('update_category_result')+'</div>');
            localStorage.removeItem('update_category_result');
        }
	});

	/**************************** initial load ****************************/
	$('#product_manufacture').val('<?php echo $product_manufacture;?>');
	$('#product_category').val('<?php echo $product_category;?>');

	// wysiwyg for short and long description
	var wysiwyg_config = {
		skin: 'moono',
		enterMode: CKEDITOR.ENTER_BR,
		shiftEnterMode:CKEDITOR.ENTER_P,
		toolbar: [{ name: 'basicstyles', groups: [ 'basicstyles' ], items: [ 'Bold', 'Italic', 'Underline', "-", 'TextColor', 'BGColor' ] },
				{ name: 'styles', items: [ 'Format', 'Font', 'FontSize' ] },
				{ name: 'scripts', items: [ 'Subscript', 'Superscript' ] },
				{ name: 'justify', groups: [ 'blocks', 'align' ], items: [ 'JustifyLeft', 'JustifyCenter', 'JustifyRight', 'JustifyBlock' ] },
				{ name: 'paragraph', groups: [ 'list', 'indent' ], items: [ 'NumberedList', 'BulletedList', '-', 'Outdent', 'Indent'] },
				{ name: 'links', items: [ 'Link', 'Unlink' ] },
				{ name: 'insert', items: [ 'Image'] },
				{ name: 'spell', items: [ 'jQuerySpellChecker' ] },
				{ name: 'table', items: [ 'Table' ] }
				],
	}
	CKEDITOR.replace('product_store_description', wysiwyg_config);
	CKEDITOR.replace('product_feature_description', wysiwyg_config);

	// product keywords selectize option
	$('#product_keywords').selectize({
    	plugins: ['remove_button','drag_drop','restore_on_backspace'],
        delimiter: ',',
        persist: false,
        create: function(input){
            return {
                value: input,
                text:  input
            }
        }
    });

	// product feature, included selectize option
	$('#product_feature, #product_included').selectize({
    	plugins: ['remove_button','drag_drop','restore_on_backspace'],
        delimiter: ',',
        persist: false,
        create: function(input){
            return {
                value: input,
                text:  input
            }
        },
        render:{
            item: function(item, escape) {
                return '<div class="col-md-11 col-lg-11">'+item.text+'</div>';
            },
            option: function(item, escape) {
                return '<div class="col-md-11 col-lg-11">'+item.text+'</div>';
            }
        }
    });

	// related product select2 option
    function custom_template(obj){
            var data = $(obj.element).data();
            var text = $(obj.element).text();
            if(data && data['img_src']){
                img_src = data['img_src'];
                template = $("<div class='row'><div class='col-md-6'><img src=\"" + img_src + "\" style=\"width:100px;height:100px;\"/></div><div class='col-md-6'><p>" + text + "</p></div></div>");
                return template;
            }
    }
    var options = {
        'templateSelection': custom_template,
        'templateResult': custom_template,
        'placeholder': "Select products",
    }
    $('#product_related').select2(options);
    $('#product_related').val([<?php echo $related?>]);
	$('#product_related').trigger('change');

	// treeview for category tab  
    var treedata = <?php echo $category_tree; ?>;
    $('#cat_tree').jstree({
        'core': {
            'data': treedata,
            'themes': {
		    	'icons': false,
		    },
        },
        'plugins': ["checkbox", "grid", "search"],
        'grid': {
            'columns': [
                {width: '90%', header: "Categoriy List"},
                {width: '10%', header: "Primary", value: "radio"}
            ],
        },
        'search': {
		    'show_only_matches': true,
		    'show_only_matches_children': true
		},
		
    });
    // tree view on change 
    $('#cat_tree').on('changed.jstree', function (e, data) {
    	$('#associatedCatID').val(data.selected);
    	var prim = $("input[name='prim_category']:checked").val();
    	$('#cat_tree').jstree("select_node", prim);
  	});
  	// search in category tree
    $('#search').on("keyup change", function () {
		$('#cat_tree').jstree(true).search($(this).val())
	});
  	

	/***************************** end of initial load *****************************/


    /********************** add/remove battery type ***************************/
	$("#add_battery").click(function(){
    	var action = "add_more_battery";
    	$.ajax({
            type:"post",
            url:"product_action.php",
            data:{
                    action:action
            },
            success: function(mess){
                $('#battery_table').append(mess);
  				$('#battery_table').find('select').addClass('form-control');
            }
        });
    });
	$("#battery_table").on("click", "#remove_battery", function () {
    	if(confirm("Remove Cannot Be Undo. Are You Sure???")){
        	$(this).closest("tr").remove();     
        }
    });

    /********************** submit GENERAL form ***************************/
    $('#product_update_form').submit(function(e){
    	event.preventDefault();
    	var product_store_description = (CKEDITOR.instances['product_store_description']).getData();
        var product_feature_description = (CKEDITOR.instances['product_feature_description']).getData();
        var data = new FormData(this);
        data.append("action", "update_general");
        data.append("productid", "<?php echo $productid?>");
        data.append("product_store_description", product_store_description);
        data.append("product_feature_description", product_feature_description);
        $.ajax({
            type:"post",
            url:"product_action.php",
            data:data,
        	contentType: false,
            cache: false,
            processData:false,
            success: function(mess){
            	localStorage.setItem("update_general_result", mess);
                window.location.reload(); 
            }
        });
    });

    /********************** submit EXTRA form ***************************/
    $('#product_extra_form').submit(function(e){
    	event.preventDefault();
        var data = new FormData(this);
        data.append("action", "update_extra");
        data.append("productid", "<?php echo $productid?>");
        $.ajax({
            type:"post",
            url:"product_action.php",
            data:data,
        	contentType: false,
            cache: false,
            processData:false,
            success: function(mess){
            	var result = JSON.parse(mess);
            	var string = '';
            	if(result.feature_result == '' && result.included_result == '' && result.battery_result == '' && result.related_result == ''){
            		string = 'Nothing Updated';
            	}
            	else{
            		string = result.feature_result+' - '+result.included_result+' - '+result.battery_result+' - '+result.related_result;
            	}
            	localStorage.setItem("update_extra_result", string);
                window.location.reload(); 
            }
        });
    });



    
  	/********************** submit CATEGORY form ***************************/
  	$('#product_category_form').submit(function(e){
    	event.preventDefault();
        var data = new FormData(this);
        data.append("action", "update_category");
        data.append("productid", "<?php echo $productid?>");
        $.ajax({
            type:"post",
            url:"product_action.php",
            data:data,
        	contentType: false,
            cache: false,
            processData:false,
            success: function(mess){
            	localStorage.setItem("update_category_result", mess);
                window.location.reload(); 
            }
        });
    });



  	/********************** on change images ***************************/
	$("#imageids").change(function(){
		var imageids = $("#imageids").val();
    	var action = "add_associated_image";
    	$.ajax({
            type:"post",
            url:"product_action.php",
            data:{
                imageids:imageids,action:action
            },
            success: function(mess){
            	alert(mess);
                //$('#image_table_body').append(mess);
  				//$('#battery_table').find('select').addClass('form-control');
            }
        });
    });

    /********************** submit IMAGE form ***************************/
  	$('#product_category_form').submit(function(e){
    	event.preventDefault();
        var data = new FormData(this);
        data.append("action", "update_category");
        data.append("productid", "<?php echo $productid?>");
        $.ajax({
            type:"post",
            url:"product_action.php",
            data:data,
        	contentType: false,
            cache: false,
            processData:false,
            success: function(mess){
            	localStorage.setItem("update_category_result", mess);
                window.location.reload(); 
            }
        });
    });


});
</script>

<?php
include('../footer.php');
?>