<?php

/************* Manufacture list***********/
function manufacture_list($cms_connect){
    $sql = "SELECT id, name FROM list_manufacture ORDER BY id";
    $result = $cms_connect->query($sql);
    $output = '';
    foreach ($result as $row){
        $output .='<option value = "'.$row['id'].'">'.$row['name'].'</option>';
    }
    return $output;
}

/************* site category list***********/
function category_list($cms_connect){
    $sql = "SELECT id, label FROM list_product_category ORDER BY id";
    $result = $cms_connect->query($sql);
    $output = '';
    foreach ($result as $row){
        $output .='<option value = "'.$row['id'].'">'.$row['label'].'</option>';
    }
    return $output;
}

/************* Product Battery list***********/
function battery_list($cms_connect){
    $sql = "SELECT id, type FROM list_product_battery ORDER BY type";
    $result = $cms_connect->query($sql);
    $output = '';
    foreach ($result as $row){
        $output .='<option value = "'.$row['id'].'">'.$row['type'].'</option>';
    }
    return $output;
}

/************* Product Battery selected***********/
function battery_id_selected($cms_connect, $selected){
    $sql = "SELECT id, type FROM list_product_battery ORDER BY type";
    $result = $cms_connect->query($sql);
    $output = '';
    foreach ($result as $row){
        if($row['id'] == $selected){
            $output .='<option value = "'.$row['id'].'" selected>'.$row['type'].'</option>';
        }
        else{
            $output .='<option value = "'.$row['id'].'">'.$row['type'].'</option>';
        }
        
    }
    return $output;
}

// get product general info
function product_info_by_id($cms_connect, $productid){
	$sql = "SELECT * FROM product WHERE id = $productid";
	$stmt = $cms_connect->query($sql);
	return $stmt->fetch_assoc();
}

// get product feature
function product_feature_by_id($cms_connect, $productid){
	$feature = array();
	$featuresql = "SELECT id, feat_item FROM product_feature WHERE product_id = $productid ORDER BY feature_order";
	$featurestmt = $cms_connect->query($featuresql);
	while($frow = $featurestmt->fetch_assoc()){
		$feature[] = $frow['feat_item'];	
	}
	return $feature;
}

// get product included
function product_included_by_id($cms_connect, $productid){
	$included = array();
	$includedsql = "SELECT id, included_items FROM product_included WHERE product_id = $productid ORDER BY included_order";
	$includedstmt = $cms_connect->query($includedsql);
	while($irow = $includedstmt->fetch_assoc()){
		$included[] = $irow['included_items'];	
	}
	return $included;
}

// get product battery
function product_battery_by_id($cms_connect, $productid){
	$battery = array();
	$batterysql = "SELECT id, battery_id FROM product_battery WHERE product_id = $productid";
	$batterystmt = $cms_connect->query($batterysql);
	while($brow = $batterystmt->fetch_assoc()){
		$battery[] = $brow['battery_id'];	
	}
	return $battery;
}

// get product related
function product_related_by_id($cms_connect, $productid){
	$related = array();
	$relatedsql = "SELECT id, related_product_id FROM list_related_product WHERE product_id = $productid";
	$relatedstmt = $cms_connect->query($relatedsql);
	while($rrow = $relatedstmt->fetch_assoc()){
		$related[] = $rrow['related_product_id'];	
	}
	return $related;
}

// product sku, name, main image for related product selection
function product_list_by_brand($cms_connect, $brand){
	$sql = 'SELECT p.sku, p.id, m.site, fm.file_name, p.feature_name
			FROM product p LEFT JOIN file_manager fm ON fm.ID = p.main_img_id
                            LEFT JOIN list_manufacture m ON m.id = p.manufacture
                            WHERE p.manufacture = '.$brand;
	$output = '';
	$stmt = $cms_connect->query($sql);
	foreach ($stmt as $row){ 
		$src = $row['site'].'/images/'.$row['file_name'];
		$output .= '<option value="'.$row['id'].'" data-img_src="'.$src.'">'.$row['sku'].' - '.$row['feature_name'].'</option>';
    }
	
	return $output;
}

// treeview with pre-selected data
function treeview_category_array($cms_connect, $productid){	
	// get all associated and primary category
	$associatedArr = array();
	$prim = 0;
	$sql = "SELECT category_id, pca_primary FROM product_category_association WHERE product_id = $productid";
	$result = $cms_connect->query($sql);
	while ($row = $result->fetch_assoc()) {
		$associatedArr[] = $row['category_id'];
		if($row['pca_primary'] == 1){
			$prim = $row['category_id'];
		}
	}

	// get all parent cat id
	$sql = 'SELECT id, label, parent FROM product_category  WHERE status = 1';
	
	$parentArray = array();
	$parentresult = $cms_connect->query($sql);
	while($parent = $parentresult->fetch_assoc()){
		if(!in_array($parent['parent'], $parentArray)){
			$parentArray[] = $parent['parent'];
		}
	}

	// tree output
	$output = array();
	$result = $cms_connect->query($sql);
	while($row = $result->fetch_assoc()){
		$tmp = array();
		$tmp['id'] = $row['id'];
		$tmp['parent'] = $row['parent'] == 0 ? '#' : $row['parent'];
		$tmp['text'] = $row['label'];
		if(in_array($row['id'], $associatedArr)){
			$tmp['state'] = array('selected' => 'true');
		}
		if(!in_array($row['id'], $parentArray)){
			if($row['id'] == $prim){
				$tmp['data'] = array('radio' => '<input type="radio" name="prim_category" value="'.$row['id'].'" checked>');
			}
			else{
				$tmp['data'] = array('radio' => '<input type="radio" name="prim_category" value="'.$row['id'].'">');
			}
		}
		$output[] = $tmp;
	}
	return $output;
}


/************* Image select option ***********/
function all_image_select_option($cms_connect){
    $sql = "SELECT DISTINCT fm.ID, concat(sl.url, ml.description, fm.file_name) as url, fm.file_name
			FROM file_manager fm LEFT JOIN site_list sl ON sl.id = fm.site_id
			                	LEFT JOIN master_list ml ON ml.id = fm.site_folder_id

			WHERE fm.file_type_id = 10 ";
    $result = $cms_connect->query($sql);
    $output = '';

    foreach ($result as $row){
    	/*$url = str_replace(' ', '%20', $row['url']);
	    $output .='<option data-content="<img width=\'50\' height=\'50\' src=\''.$url.'\'> '.$row['file_name'].'" value = "'.$row['ID'].'"></option>';*/
	    $output .='<option value = "'.$row['ID'].'">'.$row['file_name'].'</option>';	    
    }

    return $output;
}


/************* get image id ***********/
function image_info_by_id($cms_connect, $imageid){
	$output = array();
	$sql = "SELECT concat(sl.url, ml.description, fm.file_name) as url, fm.file_name
			FROM file_manager fm LEFT JOIN site_list sl ON sl.id = fm.site_id
			                	LEFT JOIN master_list ml ON ml.id = fm.site_folder_id
			WHERE fm.file_type_id = 10 AND fm.ID = $imageid";
    $result = $cms_connect->query($sql);
    $row = $result->fetch_assoc();
    $output['url'] = $row['url'];
    $output['name'] = $row['file_name'];
    return $output;
}

/*
select concat(sl.url, ml.description, fm.file_name) as url,
                       fm.file_name as name
                        from file_manager fm left join product_img pi on (pi.file_id=fm.ID) left join site_list  sl ON (sl.id=fm.site_id)
                       left join master_list ml ON (ml.id=fm.site_folder_id)
                        where fm.ID = "6830"

SELECT concat(sl.url, ml.description, fm.file_name) as url
FROM product p LEFT JOIN file_manager fm ON fm.ID = p.main_img_id
				LEFT JOIN site_list sl ON sl.id = fm.site_id
                LEFT JOIN master_list ml ON ml.id = fm.site_folder_id
                WHERE p.id = 1

SELECT concat(sl.url, ml.description, fm.file_name) as url, fm.ID
FROM product p LEFT JOIN file_manager fm ON fm.ID = p.main_img_id
				LEFT JOIN site_list sl ON sl.id = fm.site_id
                LEFT JOIN master_list ml ON ml.id = fm.site_folder_id
                WHERE fm.file_type_id = 10  

SELECT concat(sl.url, ml.description, fm.file_name) as url, fm.ID
FROM file_manager fm LEFT JOIN site_list sl ON sl.id = fm.site_id
                LEFT JOIN master_list ml ON ml.id = fm.site_folder_id
                WHERE fm.file_type_id = 10  

SELECT concat(sl.url, ml.description, fm.file_name) as url, fm.ID, fm.file_name
			FROM file_manager fm LEFT JOIN site_list sl ON sl.id = fm.site_id
			                	LEFT JOIN master_list ml ON ml.id = fm.site_folder_id
                                INNER JOIN product p ON p.main_img_id = fm.ID
			 WHERE fm.file_type_id = 10  AND p.manufacture = 2 AND fm.ID <> 0

*/


?>
