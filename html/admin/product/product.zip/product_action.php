<?php
include('../../../newconnect.php');
include('product_function.php');

// add more battery
if($_POST['action'] == 'add_more_battery'){
	//echo $_POST['action'];
    $output = "";
    $output .= "<tr>";
    $output .= "<td><select name='battery_id[]' class='form-control' required><option value=''>--- Select One ---</option>".battery_list($cms_connect)."</select></td>";
    $output .= "<td><input type='number' name='take_battery[]' min='0' value='0' class='form-control'></td>";
    $output .= "<td><input type='number' name='qty_included[]' min='0' value='0' class='form-control'></td>";
	$output .= "<td><input type='number' name='list_order[]' min='0' value='0' class='form-control'></td>";
    $output .= "<td><button type='button' id='remove_battery' class='btn btn-outline-danger btn-sm delete' title='Remove Battery'><i class='fa fa-minus'></i></button></td>";
    $output .= "</tr>";
    echo $output;
}

// add category association
if($_POST['action'] == 'add_category_association'){

    $catArr = all_category_array($cms_connect);
    $selectedArr = $_POST['selected'];
    $output = "";
    foreach($selectedArr as $selected){
		$output .= "<tr>";
		$output .= "<td>".category_parent_path($catArr, $selected).$catArr[$selected]['label']."(".$selected.")</td>";
		$output .= "<td><input type='radio' name='primary_category' value='".$selected."'></td>";
		$output .= "</tr>";
		$output .= "<input type='hidden' name='association_category[]' id='association_category' value='".$selected."'/>";
	}
	echo $output;
}


// submit Product Update - General form
if($_POST['action'] == 'update_general'){

	$product_id 					= $_POST['productid'];
	$product_name 					= $_POST['product_name'];
	$product_sku 					= $_POST['product_sku'];
	$product_nsid 					= $_POST['product_nsid'];
	$product_upc 					= $_POST['product_upc'];
	$product_manufacture 			= $_POST['product_manufacture'];
	$product_feature_name 			= $_POST['product_feature_name'];
	$product_nsn 					= $_POST['product_nsn'];
	$product_store_description 		= $_POST['product_store_description'];
	$product_feature_description 	= $_POST['product_feature_description'];
	$product_category 				= $_POST['product_category'];
	$product_keywords 				= $_POST['product_keywords'];
	$product_start_date 			= $_POST['product_start_date'] == '' ? '1969-12-31' : $_POST['product_start_date'];

	$user_id = $_SESSION['uid'];

	$updatesql = "UPDATE product SET Name = ?, sku = ?, nsid = ?, upc = ?, manufacture = ?, feature_name = ?, nsn = ?, store_desc = ?, feature_desc = ?, product_category_id = ?, keywords = ?, start_date = ?, uid_modified = ? WHERE id = ?";
	$stmt = $cms_connect->prepare($updatesql);
	$stmt->bind_param("ssisissssissii", $product_name, $product_sku, $product_nsid, $product_upc, $product_manufacture, $product_feature_name, $product_nsn, $product_store_description, $product_feature_description, $product_category, $product_keywords, $product_start_date, $user_id, $product_id);
	if($stmt->execute()){
		echo "Product Updated";
	}
	else{
		echo $cms_connect->error;
	}
	$stmt->close();

}

// submit Product Update - Extra form
if($_POST['action'] == 'update_extra'){

	// initial data
	$product_id 					= $_POST['productid'];
	$product_feature 				= $_POST['product_feature'];
	$product_included 				= $_POST['product_included'];
	$battery_idArr 					= $_POST['battery_id'];
	$take_batteryArr 				= $_POST['take_battery'];
	$qty_includedArr 				= $_POST['qty_included'];
	$list_orderArr 					= $_POST['list_order'];
	$product_relatedArr 			= $_POST['product_related'];
	
	$user_id = $_SESSION['uid'];

	$feature_result = $included_result = $battery_result = $related_result = '';
	/************* product feature *************/
	$old_featureArr = product_feature_by_id($cms_connect, $product_id);
	$new_featureArr = explode(',', $product_feature);

	if(count(array_diff($new_featureArr, $old_featureArr)) != 0 || $old_featureArr !== $new_featureArr){
		$fstmt = $cms_connect->prepare("DELETE FROM product_feature WHERE product_id = ?");
		$fstmt->bind_param("i",  $product_id);
		$fstmt->execute();
		$fstmt->close();
		$order = 10;
		foreach($new_featureArr as $feature){
			$f_insertsql = "INSERT INTO product_feature (product_id, feat_item, feature_order, uid_created, uid_modified) VALUES (?, ?, ?, ?, ?)";
			$fstmt = $cms_connect->prepare($f_insertsql);
			$fstmt->bind_param("isiii", $product_id, $feature, $order, $user_id, $user_id);
			if($fstmt->execute()){
				$feature_result = "Product Feature Updated";
				$order += 10;
			}
			else{
				$feature_result = $cms_connect->error;
			}
			$fstmt->close();
		}
	}
	
	/************* product included *************/
	$old_includedArr = product_included_by_id($cms_connect, $product_id);
	$new_includedArr = explode(',', $product_included);

	if(count(array_diff($new_includedArr, $old_includedArr)) != 0 || $new_includedArr !== $old_includedArr){
		$istmt = $cms_connect->prepare("DELETE FROM product_included WHERE product_id = ?");
		$istmt->bind_param("i",  $product_id);
		$istmt->execute();
		$istmt->close();
		$order = 10;
		foreach($new_includedArr as $included){
			$i_insertsql = "INSERT INTO product_included (product_id, included_items, included_order, uid_created, uid_modified) VALUES (?, ?, ?, ?, ?)";
			$istmt = $cms_connect->prepare($i_insertsql);
			$istmt->bind_param("isiii", $product_id, $included, $order, $user_id, $user_id);
			if($istmt->execute()){
				$included_result = "Product Included Updated";
				$order += 10;
			}
			else{
				$included_result = $cms_connect->error;
			}
			$istmt->close();
		}
	}

	/************* product battery *************/
	$old_batteryArr = product_battery_by_id($cms_connect, $product_id);
	$new_batteryArr = $battery_idArr;

	if(count(array_diff($new_batteryArr, $old_batteryArr)) != 0 || $new_batteryArr !== $old_batteryArr){
		$bstmt = $cms_connect->prepare("DELETE FROM product_battery WHERE product_id = ?");
		$bstmt->bind_param("i",  $product_id);
		$bstmt->execute();
		$bstmt->close();

		for($i = 0; $i < count($battery_idArr); $i++){
			$b_insertsql = "INSERT INTO product_battery (product_id, battery_id, battery_order, battery_qty, included, uid_created, uid_modified) VALUES (?, ?, ?, ?, ?, ?, ?)";
			$bstmt = $cms_connect->prepare($b_insertsql);
			$bstmt->bind_param("iiiiiii", $product_id, $battery_idArr[$i], $list_orderArr[$i], $take_batteryArr[$i], $qty_includedArr[$i], $user_id, $user_id);
			if($bstmt->execute()){
				$battery_result = "Product Battery Updated";
			}
			else{
				$battery_result = $cms_connect->error;
			}
			$bstmt->close();
		}
	}

	/************* product related *************/
	$old_relatedArr = product_related_by_id($cms_connect, $product_id);
	$new_relatedArr = $product_relatedArr;

	if(count(array_diff($new_relatedArr, $old_relatedArr)) != 0 || $old_relatedArr !== $new_relatedArr){
		$rstmt = $cms_connect->prepare("DELETE FROM list_related_product WHERE product_id = ?");
		$rstmt->bind_param("i",  $product_id);
		$rstmt->execute();
		$rstmt->close();
		$order = 10;
		foreach($new_relatedArr as $related){
			$r_insertsql = "INSERT INTO list_related_product (product_id, related_product_id, related_product_order, uid_created, uid_modified) VALUES (?, ?, ?, ?, ?)";
			$rstmt = $cms_connect->prepare($r_insertsql);
			$rstmt->bind_param("iiiii", $product_id, $related, $order, $user_id, $user_id);
			if($rstmt->execute()){
				$related_result = "Product Related Updated";
				$order += 10;
			}
			else{
				$related_result = $cms_connect->error;
			}
			$rstmt->close();
		}
	}

	$output = array();
	$output['feature_result'] = $feature_result;
	$output['included_result'] = $included_result;
	$output['battery_result'] = $battery_result;
	$output['related_result'] = $related_result;
	echo json_encode($output);
}

// submit Product Add form
if($_POST['action'] == 'add_product'){

	$product_name 					= $_POST['product_name'];
	$product_sku 					= $_POST['product_sku'];
	$product_nsid 					= $_POST['product_nsid'];
	$product_upc 					= $_POST['product_upc'];
	$product_manufacture 			= $_POST['product_manufacture'];
	$product_feature_name 			= $_POST['product_feature_name'];
	$product_nsn 					= $_POST['product_nsn'];
	$product_store_description 		= $_POST['product_store_description'];
	$product_feature_description 	= $_POST['product_feature_description'];
	$product_category 				= $_POST['product_category'];
	$product_keywords 				= $_POST['product_keywords'];
	$product_start_date 			= $_POST['product_start_date'] == '' ? '1969-12-31' : $_POST['product_start_date'];

	$user_id = $_SESSION['uid'];

	$new_product_id = $add_result = '';

	$insertsql = "INSERT INTO product (Name, sku, nsid, upc, manufacture, feature_name, nsn, store_desc, feature_desc, product_category_id, keywords, start_date, uid_created, uid_modified) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
	$stmt = $cms_connect->prepare($insertsql);
	$stmt->bind_param("ssisissssissii", $product_name, $product_sku, $product_nsid, $product_upc, $product_manufacture, $product_feature_name, $product_nsn, $product_store_description, $product_feature_description, $product_category, $product_keywords, $product_start_date, $user_id, $user_id);
	if($stmt->execute()){
		$add_result = "Product Added";
		$new_product_id = $stmt->insert_id;
	}
	else{
		$add_result =  $cms_connect->error;
	}
	$stmt->close();
	
	$output = array();
	$output['add_result'] = $add_result;
	$output['new_product_id'] = $new_product_id;
	echo json_encode($output);
}

// submit Category form
if($_POST['action'] == 'update_category'){

	$product_id = $_POST['productid'];
	$associatedCatIDArr = explode(',', $_POST['associatedCatID']);
	$prim_category = $_POST['prim_category'];
	$user_id = $_SESSION['uid'];
	
	// delete all association
	$cat_delete_stmt = $cms_connect->prepare("DELETE FROM product_category_association WHERE product_id = ?");
	$cat_delete_stmt->bind_param("i",  $product_id);
	$cat_delete_stmt->execute();

	// insert new association
	foreach($associatedCatIDArr as $associatedCatID){
		$prim = $associatedCatID == $prim_category ? 1 : 0;
		$insertsql = "INSERT INTO product_category_association (product_id, category_id, pca_primary, uid_created, uid_modified) VALUES (?,?,?,?,?)";
		$insert_cat_stmt = $cms_connect->prepare($insertsql);
		$insert_cat_stmt->bind_param("iiiii", $product_id, $associatedCatID, $prim, $user_id, $user_id);
		if($insert_cat_stmt->execute()){
			$result = 'Category Association Updated';
		}
		else{
			$result = 'Failed';
		}
	}
	echo $result;
}

// add associated images
if($_POST['action'] == 'add_associated_image'){
	$imageArr = $_POST['imageids'];
	echo count($imageArr);
	/*$imageArr = $_POST['imageids'];

	$output = "";
	foreach ($imageArr as $imageid {
		$tmpArr = image_info_by_id($cms_connect, $imageid);
		$output .= "<tr>";
	    $output .= "<td><img src='".$tmpArr['url']."' width=100 height=100></td>";
	    $output .= "<td>".$tmpArr['name']."</td>";
	    $output .= "<td><input type='text' name='description[]' class='form-control'></td>";
		$output .= "<td><input type='radio' name='primary_image[]' class='form-control'></td>";
	    $output .= "<td>abc</td>";
	    $output .= "</tr>";
	    $output .= $tmpArr['name'];

	}
	echo $output;
	//echo $tmpArr['name'];*/
}

?>