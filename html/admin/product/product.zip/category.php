<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

include('../../../newconnect.php');
include('header.php');
include('product_function.php');

$list = json_encode(product_category_array($cms_connect));
?>



<div class="content mt-3">

<link rel="stylesheet" href="../css/simTree.css">


<span id="alert_action"></span>
    <div class="row">
        <div class="col-lg-12">
            <div class="card">
                <div class="card-header">
                    <div class="col-lg-6 col-md-6 col-sm-6 col-xs-6">
                        <strong class="card-title">Category Association</strong>
                    </div>
                </div>
                <div class="card-body">
                	
                	<div id="tree"></div>

                </div>
            </div>
        </div>
    </div>
        
    
	<script src="../js/simTree.js"></script>
    <script>
        var list = <?php echo $list;?>;
        var tree = simTree({
            el: '#tree',
            data: list,
            check: true,
            linkParent: true,
            //check: true,
            onClick: function (item) {
                console.log(item)
            },
            onChange: function (item) {
                console.log(item)
            }
        });
    </script>
       

</div> <!-- end of display content -->
<?php
include '../footer.php';
?>